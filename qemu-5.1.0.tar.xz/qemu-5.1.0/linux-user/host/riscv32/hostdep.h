/*
 * hostdep.h : things which are dependent on the host architecture
 *
 * This work is licensed under the terms of the GNU GPL, version 2 or later.
 * See the COPYING file in the top-level directory.
 */

#ifndef RISCV32_HOSTDEP_H
#define RISCV32_HOSTDEP_H

#endif
